"""Los datos de ejemplo no deben chocar entre sí (migración + datos de prueba)."""
import datos_prueba
from almacen_sqlite import AgendaSQLite
from main import BASE, cargar_negocio


def test_migracion_y_datos_de_prueba_no_chocan(ruta_db):
    AgendaSQLite(ruta_db, cargar_negocio()["servicios"]).importar_json(BASE / "reservas.json")
    assert datos_prueba.main(ruta_db) == 3
