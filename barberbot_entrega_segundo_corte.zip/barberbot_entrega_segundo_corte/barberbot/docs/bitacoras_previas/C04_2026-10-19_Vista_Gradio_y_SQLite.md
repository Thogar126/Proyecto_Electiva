---
tipo: bitacora-clase
curso: electiva ll
periodo: EAM-2026II
equipo: Rodriguez_Anduquia_Hurtado_Garcia
corte: 2
semana: "4"
clase: "04"
fecha: 2026-10-19
estado: en-progreso
tags:
  - chatbots
  - bitacora
  - barberia
---

# Bitácora — Clase 4

## 1. Datos de la sesión

|Campo|Registro|
|---|---|
|Tema|Vista Gradio · SQLite · Disponibilidad de intervalos · Docker|
|Objetivo|Integrar BarberBot con una interfaz web en Gradio que conserve una conversación por sesión, guardar las reservas en SQLite mediante FastAPI y comprobar que las reservas no se crucen, que se puedan modificar y cancelar, y que los datos persistan después de reiniciar la API.|
|Proyecto|Chatbot de reservas para una barbería — BarberBot|
|Inicio|Por completar|
|Cierre|Por completar|

## 2. Participación y responsabilidades

|Integrante|Asistió|Rol de la clase|Responsabilidad asumida|Aporte verificable|
|---|:-:|---|---|---|
|Juan Sebastián Rodríguez|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|
|Juan José Anduquia|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|
|David Hurtado|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|
|Thomas García|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|

## 3. Reto aplicado al proyecto

### Funcionalidad trabajada

Durante esta sesión se integró BarberBot como una aplicación completa: una interfaz web, un chatbot con una conversación por sesión y una API que guarda las reservas en una base de datos persistente, validando que los intervalos no se crucen.

Se trabajó en los siguientes componentes:

- **Gradio (`app_gradio.py`):** interfaz con el chat, los botones Enviar, Confirmar operación, Descartar solicitud y Reiniciar conversación, y una tabla de reservas guardadas. El estado se guarda por sesión con `gr.State`.

- **SQLite (`almacen_sqlite.py`):** tabla `reservas` con código, cliente, servicio, fecha, hora, duración y estado. Cada operación usa su propia conexión.

- **Disponibilidad:** una reserva ocupa un intervalo completo según la duración de su servicio. Dos intervalos se cruzan cuando `inicio_nuevo < fin_existente` y `fin_nuevo > inicio_existente`.

- **Transacciones:** la comprobación del cruce y el guardado se hacen en la misma transacción con `BEGIN IMMEDIATE`.

- **FastAPI (`main.py`):** los endpoints de reservas consultan y escriben en SQLite; cancelar cambia el estado a `cancelada` y libera el intervalo.

- **Manejo de errores:** la interfaz muestra el detalle que devuelve FastAPI, incluido el HTTP 409 por cruce de horario.

- **Docker:** `Dockerfile` y `docker-compose.yml` con un servicio para la API y otro para Gradio, y la base guardada en un volumen.

- **Pruebas automáticas:** 26 pruebas con `pytest` para la API, el chatbot y la interfaz.

### Criterios de aceptación

- [x] Mostrar el chatbot en una interfaz web con Gradio.
- [x] Conservar una conversación independiente por sesión.
- [x] Guardar las reservas en SQLite a través de FastAPI.
- [x] Consultar la disponibilidad real según la duración del servicio.
- [x] Crear reservas con confirmación del usuario.
- [x] Rechazar con HTTP 409 una reserva que se cruza con otra, aunque empiece a una hora distinta.
- [x] Aceptar una reserva que empieza justo cuando termina la anterior.
- [x] Modificar una reserva hacia un intervalo libre y conservar los datos si el nuevo intervalo está ocupado.
- [x] Cancelar una reserva y recuperar su intervalo disponible.
- [x] Descartar una solicitud pendiente sin crear una fila.
- [x] Reiniciar la conversación sin perder las reservas guardadas.
- [x] Garantizar que solo una de dos solicitudes simultáneas al mismo intervalo sea aceptada.
- [x] Verificar que las reservas continúan en la base después de reiniciar la API.
- [ ] Probar el despliegue con Docker Compose.
- [ ] Migrar las reservas de `reservas.json` con `almacen_sqlite.py --migrar`.
- [ ] Adjuntar las capturas finales y los enlaces verificables de las evidencias.

_Nota: los criterios marcados corresponden a las funcionalidades implementadas y a las pruebas realizadas durante el desarrollo. Las verificaciones pendientes deben completarse antes de entregar la evidencia definitiva._

### Archivos o componentes modificados

- `app_gradio.py`: interfaz web con el chat, los botones, la tabla de reservas y el detalle de los errores HTTP.
- `almacen_sqlite.py`: almacenamiento de reservas, validación de intervalos y migración desde JSON. Archivo entregado por el docente e integrado sin cambios.
- `main.py`: endpoints de reservas conectados a `AgendaSQLite`.
- `consulta_llm.py`: se añadió `detalle_error()` para extraer el mensaje que devuelve FastAPI.
- `Dockerfile` y `docker-compose.yml`: ejecución de la API y de Gradio en contenedores.
- `.env.example`, `.gitignore` y `.dockerignore`: configuración sin exponer la clave de Groq.
- `datos_prueba.py` y `reservas.json`: reservas de ejemplo para las evidencias y la migración.
- `listar_modelos_groq.py`: consulta de los modelos habilitados para la clave.
- `README.md`: instrucciones de instalación, ejecución y respuestas de la entrega.

Las rutas corresponden a los archivos del proyecto BarberBot. Deben verificarse en la carpeta de trabajo antes de adjuntar capturas o enlaces.

## 4. Decisiones técnicas

|Decisión|Razón|Alternativa descartada|
|---|---|---|
|Guardar las reservas en SQLite|Persistencia sin instalar un servidor de base de datos; las reservas sobreviven a los reinicios.|Dejar las reservas en memoria o en un archivo JSON.|
|Una sola fuente de verdad: los endpoints solo leen y escriben en SQLite|Si una operación escribiera en un JSON y otra consultara SQLite, los resultados no coincidirían.|Mantener dos fuentes de datos.|
|Calcular el cruce con la duración del servicio|Una reserva de 60 minutos a las 10:00 bloquea también las 10:30, aunque otro servicio empiece a otra hora.|Comparar solo la hora de inicio.|
|Comprobar y guardar en una misma transacción con `BEGIN IMMEDIATE`|Dos personas pueden ver libre el mismo horario; la segunda escritura espera, vuelve a leer y detecta el cruce.|Comprobar la disponibilidad en una consulta y guardar en otra.|
|Cancelar cambiando el estado a `cancelada`|Se libera el intervalo y se conserva el histórico de la reserva.|Borrar la fila de la base de datos.|
|Usar consultas parametrizadas (`?`)|El texto de la persona nunca se concatena dentro del SQL.|Construir el SQL con texto concatenado.|
|Usar `gr.State` para el estado de cada sesión|Cada ventana del navegador tiene su propio historial, su pantalla y su operación pendiente.|Variables globales compartidas por todos los usuarios.|
|Botones Confirmar, Descartar y Reiniciar|La operación solo se ejecuta cuando la persona la confirma; descartar y reiniciar no escriben en la base.|Ejecutar la operación apenas el modelo la interpreta.|
|Mostrar el detalle de los errores HTTP con `detalle_error()`|El usuario ve la causa real, por ejemplo que el intervalo se cruza, en lugar de un error genérico.|Mensajes genéricos de «error HTTP».|
|Una cola común con límite de concurrencia 1 para los eventos de Gradio|Evita que se solapen el envío, la confirmación y el reinicio de una misma conversación.|Eventos sin control de concurrencia.|
|Usar Docker Compose con dos servicios y un volumen para `reservas.db`|Reproduce el proyecto en cualquier equipo y conserva la base entre reinicios del contenedor.|Instalar y ejecutar cada componente a mano.|
|Leer la clave de Groq solo desde variables de entorno|La clave no queda en el código, en la imagen de Docker ni en los archivos entregados.|Escribir la clave en un archivo del proyecto.|
|Escribir pruebas automáticas con `pytest`|Permiten repetir los casos del laboratorio (cruce, contigua, modificar, cancelar, concurrencia) en segundos.|Probar todo a mano en cada cambio.|

## 5. Problemas y soluciones

|Problema encontrado|Causa identificada|Solución aplicada|¿Cómo se verificó?|
|---|---|---|---|
|HTTP 409 al reservar un corte a las 10:30.|La API detectó que se cruza con una reserva de `corte_barba` de 60 minutos que empieza a las 10:00.|Es el comportamiento esperado: se muestra el detalle del error y se elige otra hora libre.|Prueba `test_cruce_de_intervalos_se_rechaza` y rechazo en Gradio; una reserva a las 11:00 sí fue aceptada.|
|Dos personas podían reservar el mismo intervalo a la vez.|Comprobar y guardar por separado deja una ventana entre las dos operaciones.|`BEGIN IMMEDIATE` bloquea las escrituras y la comprobación del cruce se hace dentro de la transacción.|Prueba con 8 hilos sobre el mismo intervalo: una reserva aceptada y siete conflictos.|
|`uvicorn --reload` se reiniciaba por cambios en archivos de `.venv`.|El modo `--reload` vigila los archivos del proyecto, incluida la carpeta del entorno virtual.|Se ejecutó la API sin `--reload` para las pruebas y la presentación.|La API arrancó una sola vez y mantuvo el servicio estable.|
|`reservas.db` no se podía abrir en Visual Studio Code.|Es un archivo binario de SQLite, no un archivo de texto.|Se consultó la tabla con Python, desde `/api/reservas` y desde el acordeón «Reservas guardadas» de Gradio.|Se listaron las filas con código, cliente, servicio, fecha, hora y estado.|
|Una reserva cancelada debía dejar libre su intervalo.|Si seguía contando como ocupada, el horario no volvería a aparecer.|Cancelar cambia el estado a `cancelada` y el cálculo de ocupación solo considera las reservas `activa`.|Prueba `test_cancelar_libera_el_intervalo` y consulta de disponibilidad antes y después.|
|Modificar hacia un intervalo ocupado no debía perder los datos anteriores.|Una modificación fallida a mitad podría dejar la reserva en un estado incoherente.|La modificación se hace en una sola transacción; si hay conflicto, se revierte y se responde 409.|Prueba `test_modificar_a_hora_ocupada_conserva_datos`.|

## 6. Evidencias

|Tipo|Descripción|Enlace o ruta|
|---|---|---|
|Código|Interfaz web con Gradio.|`app_gradio.py`|
|Código|API con endpoints de reservas.|`main.py`|
|Código|Almacenamiento, intervalos y transacciones en SQLite.|`almacen_sqlite.py`|
|Código|Manejo de errores HTTP y peticiones.|`consulta_llm.py`|
|Código|Contenedores de la API y de Gradio.|`Dockerfile` · `docker-compose.yml`|
|Base de datos|Archivo SQLite con las reservas de prueba.|`reservas.db` — adjuntar captura de la consulta `SELECT`|
|Pruebas|26 pruebas automáticas.|`tests/` — adjuntar captura de `python -m pytest -q`|
|Prueba de ejecución|FastAPI y Gradio ejecutándose localmente.|FastAPI: `http://127.0.0.1:8011/docs` · Gradio: `http://127.0.0.1:7860` — adjuntar capturas|
|Prueba funcional|Solicitud completada en varios turnos, confirmación y fila guardada.|Adjuntar captura del chat y de la tabla de reservas|
|Prueba funcional|Rechazo del cruce de intervalos (HTTP 409) y reserva contigua aceptada.|Adjuntar captura del aviso y de las dos reservas|
|Prueba funcional|Disponibilidad antes y después de reservar y de cancelar.|Adjuntar captura de las tres consultas|
|Prueba funcional|Modificación a un intervalo libre y a uno ocupado.|Adjuntar captura del antes y del después|
|Prueba funcional|Solicitud descartada sin crear una fila.|Adjuntar captura de la tabla|
|Prueba de sesiones|Ventana normal y ventana privada con conversaciones separadas.|Adjuntar captura de las dos ventanas|
|Prueba de persistencia|Reservas conservadas después de reiniciar la API.|Adjuntar captura antes y después del reinicio|

## 7. Uso de inteligencia artificial

> [!important] Registrar la IA no reemplaza la explicación técnica. El equipo debe verificar, adaptar y comprender cualquier resultado utilizado.

|Herramienta|Objetivo o pregunta|Qué se utilizó|Cómo se verificó|Qué se modificó|
|---|---|---|---|---|
|Claude (Anthropic)|Construir el proyecto BarberBot, integrar Gradio, SQLite y Docker, guiar la ejecución y resolver errores durante las pruebas.|Código del proyecto, pruebas automáticas, instrucciones de ejecución y orientación para diagnosticar el error de la clave de Groq.|Se ejecutaron las pruebas automáticas, se probaron los endpoints y el chat, y se contrastaron los resultados con las filas de SQLite y los códigos HTTP de FastAPI.|Por completar con los cambios que realizó el equipo.|
|Groq|Interpretar las solicitudes de los usuarios y convertirlas en acciones estructuradas.|Modelo: por completar (ID del modelo usado) y salida JSON con los datos de cada operación.|Se revisaron los planes interpretados en «Revisar historial del laboratorio» para consultas, creación, modificación y cancelación.|Se adaptó el prompt al dominio de la barbería y a los datos requeridos por cada acción.|

El equipo verificó los resultados mediante pruebas de ejecución. La inteligencia artificial se utilizó como apoyo para el desarrollo y la depuración; la disponibilidad y las reservas se resuelven con la lógica de Python y SQLite a través de FastAPI.

## 8. Defensa técnica y retroalimentación

|Campo|Registro|
|---|---|
|Integrante que defendió||
|Pregunta recibida||
|Respuesta resumida||
|Retroalimentación docente||
|Mejora acordada||

### Preguntas de preparación para la defensa

**¿Qué función recibe el mensaje?**

`enviar()` en `app_gradio.py`, cuando se pulsa Enviar o Enter. Esa función llama a `procesar_turno()` en `chatbot_memoria.py`.

**¿Dónde vive el historial?**

En `estado["historial"]`, un `gr.State` por sesión del navegador. Se envía a Groq en cada turno. `estado["pantalla"]` es solo lo que ve la persona.

**¿Qué endpoint ejecuta cada operación y qué SQL le corresponde?**

Crear: `POST /api/reservas`, con `INSERT INTO reservas VALUES (...)`. Modificar: `PUT /api/reservas/{codigo}`, con `UPDATE reservas SET servicio=?, fecha=?, hora=?, duracion_minutos=? WHERE codigo=?`. Cancelar: `DELETE /api/reservas/{codigo}`, con `UPDATE reservas SET estado='cancelada' WHERE codigo=?`. Consultar la disponibilidad: `GET /api/disponibilidad`, con `SELECT hora, duracion_minutos FROM reservas WHERE fecha=? AND estado='activa'`.

**¿Por qué la comprobación de disponibilidad y el guardado van en una misma transacción?**

Dos personas pueden ver libre el mismo horario. `BEGIN IMMEDIATE` bloquea las escrituras: la segunda espera, vuelve a leer las reservas con la primera ya guardada, detecta el cruce y recibe un 409. Si comprobara y guardara por separado, ambas podrían insertar.

**¿Cuál es la diferencia entre el historial de la conversación y SQLite?**

El historial conserva los mensajes para dar contexto a Groq y vive en la sesión. SQLite guarda las reservas y sus estados de forma persistente. Reiniciar el chat borra el historial, pero las reservas siguen guardadas.

**¿Qué significa el error HTTP 409?**

Hay un conflicto con el estado actual del recurso. En BarberBot indica que el intervalo se cruza con una reserva activa, o que la reserva ya no está activa.

**¿Por qué cancelar no borra la fila?**

Para conservar el histórico. La fila queda con estado `cancelada` y deja de contar como intervalo ocupado.

## 9. Aprendizajes

Durante esta sesión se comprendió que un chatbot de reservas necesita más que un modelo de lenguaje: requiere reglas de negocio en la API, persistencia, control de la concurrencia y una interfaz que muestre con claridad lo que ocurrió.

Se identificó que:

1. La disponibilidad se calcula con intervalos, no con horas de inicio: la duración del servicio determina qué horarios quedan bloqueados.
2. Comprobar y guardar en la misma transacción evita que dos personas ocupen el mismo intervalo.
3. Cancelar cambiando el estado conserva el histórico y libera el horario.
4. El historial de la conversación y las reservas son cosas distintas: uno vive en la sesión y las otras en SQLite.
5. `gr.State` permite que cada ventana del navegador tenga su propia conversación.
6. La confirmación del usuario y la validación de la API protegen contra errores del modelo.
7. Mostrar el detalle de los errores HTTP ayuda a entender por qué se rechazó una operación.
8. Docker permite repetir el entorno, y las claves deben mantenerse fuera de los archivos y de la imagen.
9. Las pruebas automáticas permiten comprobar las reglas de negocio cada vez que se cambia el código.

Como mejora posterior, se podría añadir más de un barbero con su propia agenda, identificando el recurso en cada reserva y comprobando los cruces dentro de ese recurso.

## 10. Revisión antes de entregar

- [ ] Todos los integrantes registraron su aporte individual verificable.
- [ ] Se adjuntaron capturas de la ejecución de FastAPI y Gradio.
- [ ] Se adjuntaron las pruebas de consulta de servicios y disponibilidad.
- [ ] Se documentaron los resultados de creación, consulta, modificación y cancelación de reservas.
- [ ] Se adjuntó la evidencia del rechazo del cruce de intervalos (HTTP 409).
- [ ] Se adjuntó la evidencia de la recuperación de la disponibilidad al cancelar.
- [ ] Se verificó la persistencia de las reservas después de reiniciar la API.
- [ ] Se verificó que dos sesiones tienen conversaciones separadas.
- [ ] Se agregaron las rutas o enlaces reales de las evidencias.
- [ ] Se declaró el uso de Claude y Groq.
- [ ] La clave de Groq no aparece en los archivos ni en las capturas.
- [ ] El equipo puede explicar la función de cada archivo y las decisiones técnicas registradas.
- [ ] Se completaron la defensa técnica y la retroalimentación real del docente.
