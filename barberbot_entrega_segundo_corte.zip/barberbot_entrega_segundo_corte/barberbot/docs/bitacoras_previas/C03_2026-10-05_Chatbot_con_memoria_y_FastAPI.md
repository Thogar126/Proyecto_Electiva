---
tipo: bitacora-clase
curso: electiva ll
periodo: EAM-2026II
equipo: Rodriguez_Anduquia_Hurtado_Garcia
corte: 2
semana: "4"
clase: "03"
fecha: 2026-10-05
estado: en-progreso
tags:
  - chatbots
  - bitacora
  - barberia
---

# Bitácora — Clase 3

## 1. Datos de la sesión

|Campo|Registro|
|---|---|
|Tema|Diseño conversacional · Groq + FastAPI · Memoria conversacional|
|Objetivo|Dejar BarberBot interpretando mensajes con Groq, conservando el contexto de la conversación y conectado a una API FastAPI que permita consultar servicios y disponibilidad, y crear, modificar o cancelar reservas con confirmación previa del usuario.|
|Proyecto|Chatbot de reservas para una barbería — BarberBot|
|Inicio|Por completar|
|Cierre|Por completar|

## 2. Participación y responsabilidades

|Integrante|Asistió|Rol de la clase|Responsabilidad asumida|Aporte verificable|
|---|:-:|---|---|---|
|Juan Sebastián Rodríguez|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|
|Juan José Anduquia|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|
|David Hurtado|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|
|Thomas García|Por completar|Por completar|Por completar|Por completar con la evidencia correspondiente.|

## 3. Reto aplicado al proyecto

### Funcionalidad trabajada

Se construyó el núcleo conversacional de BarberBot: un chatbot que recibe una solicitud en lenguaje natural, la convierte en un plan estructurado y ejecuta la operación real a través de una API.

Se trabajó en los siguientes componentes:

- **Groq:** interpreta el mensaje y responde siempre con un objeto JSON con la acción y los datos identificados (`accion`, `cliente`, `servicio`, `fecha`, `hora`, `codigo`, `respuesta`).

- **Python (`chatbot_memoria.py`):** valida el plan, comprueba los datos obligatorios de cada acción, conserva los datos de turnos anteriores y prepara el resumen que el usuario debe confirmar.

- **Python (`consulta_llm.py`):** centraliza las peticiones HTTP hacia Groq y hacia FastAPI, y convierte las respuestas en mensajes legibles.

- **FastAPI (`main.py`):** expone los endpoints de servicios, disponibilidad, consulta, creación, modificación y cancelación de reservas, con respuestas 404, 409 y 422 para cada tipo de error.

- **Catálogo (`negocio.json`):** única fuente del nombre del negocio, el horario y los servicios con su precio y duración en minutos.

- **Memoria conversacional:** el historial de mensajes se conserva por sesión y se envía a Groq en cada turno; un turno que falla no se guarda como respuesta correcta.

- **Pruebas automáticas:** pruebas de la API y del flujo del chatbot en varios turnos, con un modelo simulado para no depender de la red.

### Criterios de aceptación

- [x] Adaptar el prompt, el contexto y el estado al proyecto de la barbería.
- [x] Definir un formato JSON fijo para las acciones del chatbot.
- [x] Conectar Python con Groq y con FastAPI.
- [x] Conservar el contexto entre turnos de una misma solicitud.
- [x] Exigir confirmación antes de crear, modificar o cancelar.
- [x] Adaptar FastAPI y la disponibilidad al horario de la barbería.
- [x] Integrar crear, consultar, modificar y cancelar.
- [x] Rechazar fechas inválidas, domingos, horas fuera de horario y servicios desconocidos.
- [ ] Adjuntar las capturas de las conversaciones completas y los enlaces verificables de las evidencias.

### Archivos o componentes modificados

- `negocio.json`: catálogo con cuatro servicios (corte, barba, corte_barba, tinte) y horario de lunes a sábado de 09:00 a 18:00 con pasos de 30 minutos.
- `main.py`: API FastAPI con la función `crear_app()` y el manejo de errores `responder()`.
- `consulta_llm.py`: llamada a Groq, peticiones HTTP, función `ejecutar()` y formato de las respuestas.
- `chatbot_memoria.py`: instrucciones del sistema, historial, normalización del plan y función `procesar_turno()`.
- `tests/test_api.py` y `tests/test_chatbot.py`: pruebas automáticas.
- `requirements.txt`: dependencias del proyecto.

## 4. Decisiones técnicas

|Decisión|Razón|Alternativa descartada|
|---|---|---|
|Definir un formato JSON fijo|Groq siempre devuelve `accion`, `cliente`, `servicio`, `fecha`, `hora`, `codigo` y `respuesta`, lo que permite a Python procesar la respuesta sin interpretar texto libre.|Depender de respuestas en texto libre difíciles de procesar.|
|Crear la estructura `REQUERIDOS`|Cada acción tiene sus datos obligatorios; si falta alguno, el chatbot lo pide en lugar de enviar una solicitud incompleta.|Ejecutar operaciones sin validar los datos necesarios.|
|Centralizar las peticiones HTTP en `consulta_llm.py`|Una sola función se encarga de comunicarse con Groq y con FastAPI, sin repetir la lógica de conexión en cada operación.|Duplicar las peticiones en cada archivo.|
|Usar solo la biblioteca estándar (`urllib`) para las peticiones|Reduce dependencias y mantiene el control sobre los errores HTTP.|Agregar una biblioteca externa de peticiones.|
|Configurar Groq con `temperature` en 0 y salida JSON|Respuestas más estables y fáciles de validar.|Dejar la temperatura por defecto.|
|Guardar cada respuesta del asistente como el plan JSON interpretado|Los datos dados en un turno (nombre, servicio) siguen disponibles en el siguiente.|Guardar solo texto y pedir de nuevo los datos.|
|Crear `fusionar()` y `plan_previo()`|Si el modelo no repite el nombre o el servicio en el segundo turno, Python los recupera del plan incompleto anterior.|Confiar únicamente en que el modelo recuerde todos los datos.|
|Crear `ultimo_codigo()`|Permite cancelar o modificar sin que la persona repita el código recién devuelto por la API.|Pedir siempre el código.|
|Separar el plan de la ejecución con `ejecutar(plan, confirmar=False)`|Las escrituras lanzan un error si no llegan confirmadas; el modelo solo propone y la persona decide.|Dejar que el modelo ejecute la operación directamente.|
|Guardar el historial por sesión y no en un archivo común|Evita mezclar las conversaciones de dos personas distintas.|Un único archivo de memoria compartido por todos.|
|Usar `negocio.json` como fuente única|El chatbot y la API leen el mismo catálogo y horario; cambiar un servicio no exige tocar el código.|Escribir los servicios en varios archivos.|
|Crear la API con la función `crear_app()`|Permite crear una API con una base de datos distinta para cada prueba.|Crear la API solo a nivel de módulo.|
|Responder 404, 409 y 422 con la función `responder()`|Cada error del almacén se convierte en el código HTTP correcto y el cliente puede explicarlo.|Devolver un error genérico 500.|

## 5. Problemas y soluciones

|Problema encontrado|Causa identificada|Solución aplicada|¿Cómo se verificó?|
|---|---|---|---|
|Groq respondía `HTTP Error 400: Bad Request` al listar los modelos.|La clave se pegó con `Ctrl + V` dentro de `Read-Host -AsSecureString`, que no admite ese atajo; la variable `GROQ_API_KEY` quedó con un solo carácter de control (`\x16`) en lugar de la clave.|Se volvió a pegar la clave con clic derecho, se revisó el largo y el prefijo `gsk_` de la variable y se creó una clave nueva.|Después del cambio, `listar_modelos_groq.py` mostró la lista de modelos habilitados.|
|Una solicitud llegaba en varios turnos y se podían perder el nombre y el servicio.|El modelo no siempre repite en el segundo turno los datos del primero.|Se creó `fusionar()` con `plan_previo()` para completar los campos faltantes con el plan incompleto anterior.|Prueba `test_solicitud_en_varios_turnos`.|
|Un turno que fallaba podía quedar guardado como si fuera una respuesta correcta.|El historial se actualizaba antes de saber si la API había respondido bien.|`procesar_turno()` devuelve el historial nuevo solo al final; si hay una excepción, el historial recibido queda intacto.|Prueba `test_error_de_api_no_modifica_el_historial`.|
|Una fecha inexistente como `2030-99-14` podía ser corregida por el modelo.|El modelo tiende a "arreglar" las fechas inválidas.|El prompt indica copiar la fecha tal cual si ya viene en formato `AAAA-MM-DD`, para que la API la rechace con 422.|Consulta de disponibilidad con esa fecha: la API respondió con un error 422 y el chat mostró el aviso.|
|El modelo podía devolver un servicio que no existe en el catálogo.|El usuario puede escribir un nombre distinto del identificador.|Se compara con el catálogo de `negocio.json`; si no existe, se pide de nuevo el servicio mostrando las opciones.|Prueba `test_servicio_desconocido_se_pide_de_nuevo`.|

## 6. Evidencias

|Tipo|Descripción|Enlace o ruta|
|---|---|---|
|Código|API y manejo de errores HTTP.|`main.py`|
|Código|Peticiones a Groq y FastAPI, y ejecución de planes.|`consulta_llm.py`|
|Código|Historial, plan y confirmación.|`chatbot_memoria.py`|
|Datos|Catálogo y horario de la barbería.|`negocio.json`|
|Pruebas|Pruebas automáticas de la API y del chatbot.|`tests/` — adjuntar captura de `python -m pytest -q`|
|Prueba de ejecución|FastAPI en ejecución con su documentación.|`http://127.0.0.1:8011/docs` — adjuntar captura|
|Prueba funcional|Consulta de servicios y disponibilidad desde el chat.|Adjuntar captura de la conversación|
|Prueba funcional|Solicitud completada en varios turnos con el resumen para confirmar.|Adjuntar captura de los dos turnos y del resumen|
|Prueba de memoria|Plan interpretado que conserva cliente y servicio.|Adjuntar captura de la sección «Revisar historial del laboratorio»|
|Prueba de error|Rechazo de una fecha inválida (HTTP 422).|Adjuntar captura del aviso|

## 7. Uso de inteligencia artificial

> [!important] Registrar la IA no reemplaza la explicación técnica. El equipo debe verificar, adaptar y comprender cualquier resultado utilizado.

|Herramienta|Objetivo o pregunta|Qué se utilizó|Cómo se verificó|Qué se modificó|
|---|---|---|---|---|
|Claude (Anthropic)|Construir el proyecto BarberBot a partir del enunciado del laboratorio y guiar su ejecución paso a paso.|Código de `main.py`, `consulta_llm.py`, `chatbot_memoria.py`, `negocio.json` y las pruebas, además de orientación para ejecutar y depurar.|Se ejecutaron las pruebas automáticas, se probaron los endpoints en `/docs` y se contrastaron las respuestas del chat con las de FastAPI.|Por completar con los cambios que realizó el equipo.|
|Groq|Interpretar las solicitudes de los usuarios y convertirlas en acciones estructuradas.|Modelo: por completar (ID del modelo usado) y salida JSON con los datos de cada operación.|Se revisaron los planes interpretados en el historial del chatbot.|Se adaptó el prompt al dominio de la barbería.|

El equipo verificó los resultados mediante pruebas de ejecución. La inteligencia artificial se utilizó como apoyo para el desarrollo y la depuración; la disponibilidad y las reservas las resuelven Python y FastAPI, no el modelo.

## 8. Defensa técnica y retroalimentación

|Campo|Registro|
|---|---|
|Integrante que defendió||
|Pregunta recibida||
|Respuesta resumida||
|Retroalimentación docente||
|Mejora acordada||

### Preguntas de preparación para la defensa

**¿Qué función cumple Groq?**

Interpreta el mensaje del usuario y devuelve un plan en JSON con la acción y los datos identificados. No confirma reservas ni inventa disponibilidad: eso lo hace la API.

**¿Por qué se exige confirmación antes de reservar?**

Porque el modelo solo propone la operación. `ejecutar()` lanza un error si una escritura llega sin confirmar, y la API vuelve a validar todo antes de guardar.

**¿Dónde vive el historial de la conversación?**

En el estado de la sesión del chatbot. Cada persona tiene el suyo, y se envía a Groq en cada turno junto con las instrucciones del sistema.

**¿Qué hace `REQUERIDOS`?**

Define qué datos necesita cada acción. Si falta alguno, el chatbot lo pide en lugar de llamar a la API con una solicitud incompleta.

**¿Qué significan los códigos 404, 409 y 422?**

404: la reserva no existe. 409: hay un conflicto con el estado actual, por ejemplo un horario ocupado. 422: los datos no son válidos, como una fecha inexistente o un domingo.

## 9. Aprendizajes

Durante esta sesión se comprendió que el modelo de lenguaje es solo una parte del chatbot: la validación, la memoria y la comunicación con la API hacen que sus respuestas sean confiables.

Se identificó que:

1. Groq interpreta, pero no debe decidir si una hora está libre ni dar por hecha una reserva.
2. Un formato JSON fijo hace posible validar y ejecutar lo que propone el modelo.
3. Guardar la conversación no significa que el modelo la recuerde: hay que enviarla en cada turno.
4. Exigir confirmación y volver a validar en la API protege contra errores del modelo.
5. Un turno fallido no debe quedar guardado como una respuesta correcta.
6. Los códigos HTTP 404, 409 y 422 permiten explicar al usuario qué ocurrió.
7. Las claves de acceso se manejan como variables de entorno y no se escriben en los archivos.

Como mejora posterior, falta conectar una interfaz web y una base de datos persistente para las reservas.

## 10. Revisión antes de entregar

- [ ] Todos los integrantes registraron un aporte verificable.
- [ ] Los enlaces y rutas de evidencia funcionan.
- [ ] Los criterios de aceptación están actualizados.
- [ ] El uso de IA fue declarado y verificado.
- [ ] El equipo puede explicar las decisiones registradas.
- [ ] Se completó la defensa técnica y la retroalimentación real del docente.
