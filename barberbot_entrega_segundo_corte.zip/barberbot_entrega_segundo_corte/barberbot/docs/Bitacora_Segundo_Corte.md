# Bitácora del segundo corte — BarberBot

> **Borrador.** Los campos marcados como **Por completar** (fechas reales, participación de cada integrante, resultados observados y capturas) deben llenarlos los integrantes con lo que realmente ocurrió antes de entregar.

## 1. Datos generales

| Campo | Registro |
|---|---|
| Curso | Electiva II · Creación de chatbots · EAM-2026II |
| Corte | Segundo corte |
| Proyecto | BarberBot: chatbot de reservas para una barbería |
| Integrantes | Juan Sebastián Rodríguez, Juan José Anduquia, David Hurtado, Thomas García |
| Repositorio | `<URL_DEL_REPOSITORIO>` (Por completar) |
| README | [../README.md](../README.md) |
| Presentación | [Presentacion_Segundo_Corte.pdf](Presentacion_Segundo_Corte.pdf) |
| Bitácoras de soporte | [Clase 3](bitacoras_previas/C03_2026-10-05_Chatbot_con_memoria_y_FastAPI.md) · [Clase 4](bitacoras_previas/C04_2026-10-19_Vista_Gradio_y_SQLite.md) |

## 2. Contexto y alcance

**Negocio.** Una barbería que ofrece cuatro servicios de distinta duración y precio: corte (30 min), barba (30 min), corte + barba (60 min) y tinte (90 min). Atiende de lunes a sábado, de 09:00 a 18:00, con citas cada 30 minutos. Los datos están en `negocio.json`.

**Problema.** Como cada servicio dura un tiempo distinto, agendar a mano es propenso a errores: dos citas pueden cruzarse, una reserva puede perderse y la persona no sabe qué horas hay libres. BarberBot permite hacer todo esto conversando y garantiza que las reservas no se crucen.

**Usuarios.** Las personas que quieren reservar una cita. La persona se identifica con su nombre y recibe un código para consultar, modificar o cancelar su reserva.

**Funcionalidades.**

- Consultar servicios, precios y duraciones.
- Consultar las horas libres de un día para un servicio.
- Crear, consultar, modificar y cancelar reservas.
- Completar una solicitud en varios mensajes (el bot pide los datos que faltan).
- Confirmar o descartar una operación antes de ejecutarla.
- Ver las reservas guardadas desde la interfaz.

**Límites.** Ver la sección [12](#12-limitaciones-y-mejoras-pendientes).

## 3. Arquitectura y archivos

```mermaid
flowchart LR
    P[Persona] --> G[Gradio<br/>app_gradio.py]
    G --> C[Conversación<br/>chatbot_memoria.py]
    C --> Q[Groq<br/>modelo de lenguaje]
    C --> L[consulta_llm.py<br/>peticiones HTTP]
    L --> F[FastAPI<br/>main.py]
    F --> A[almacen_sqlite.py]
    A --> D[(reservas.db<br/>SQLite)]
```

| Archivo | Responsabilidad |
|---|---|
| `app_gradio.py` | Interfaz: chat, botones, estado por sesión y tabla de reservas |
| `chatbot_memoria.py` | Prompt, historial, normalización y fusión del plan, resumen para confirmar |
| `consulta_llm.py` | Peticiones HTTP a Groq y a FastAPI, ejecución del plan y formato de las respuestas |
| `main.py` | API FastAPI: endpoints, validación de los datos y códigos de error |
| `almacen_sqlite.py` | Tabla `reservas`, transacciones, disponibilidad y migración desde JSON |
| `negocio.json` | Catálogo de servicios y horario (fuente única) |
| `tests/` | 27 pruebas automáticas |

Relación entre las piezas:

- **Gradio** solo muestra la conversación y recoge los clics; no conoce las reglas del negocio.
- **Python (`chatbot_memoria.py`)** decide qué falta pedir, qué se debe confirmar y qué se envía a la API.
- **Groq** solo interpreta el lenguaje natural y devuelve un plan.
- **FastAPI** ejecuta las operaciones del negocio y valida los datos.
- **SQLite** conserva las reservas y es la única fuente de verdad.

## 4. Consumo del modelo

| Elemento | Valor |
|---|---|
| Endpoint | `POST https://api.groq.com/openai/v1/chat/completions` |
| Headers | `Authorization: Bearer <GROQ_API_KEY>`, `Content-Type: application/json`, `Accept: application/json`, `User-Agent: BarberBot/1.0` |
| Credencial | Variable de entorno `GROQ_API_KEY`, leída al iniciar Gradio. No se escribe en archivos ni en el historial |
| Modelo | Variable `GROQ_MODEL`. Modelo usado por el equipo: **Por completar** |
| Tiempo máximo | 30 segundos por petición |

**Payload** (`llamar_groq()` en `consulta_llm.py`):

```json
{
  "model": "<GROQ_MODEL>",
  "messages": [
    {"role": "system", "content": "<instrucciones de BarberBot>"},
    {"role": "user", "content": "Quiero un corte, soy Laura"}
  ],
  "temperature": 0,
  "response_format": {"type": "json_object"}
}
```

`temperature: 0` hace las respuestas estables y `response_format` obliga al modelo a devolver un objeto JSON.

**Respuesta.** El texto del modelo está en `choices[0].message.content`. Es un texto JSON, que Python convierte con `json.loads` y valida con `normalizar_plan()`:

```json
{"accion": "crear", "cliente": "Laura", "servicio": "corte", "fecha": null, "hora": null, "codigo": null, "respuesta": null}
```

**Prompt del sistema** (`instrucciones_sistema()` en `chatbot_memoria.py`). Se arma cada vez que empieza una conversación e incluye:

- el nombre del negocio, la fecha de hoy y el día de la semana (para resolver «mañana» o «el viernes»);
- los días y el horario de atención, y el paso entre citas;
- la lista de servicios con su identificador, duración y precio;
- el formato JSON obligatorio y las acciones permitidas: `servicios`, `disponibilidad`, `listar`, `consultar`, `crear`, `modificar`, `cancelar` y `conversar`;
- reglas: usar `null` en lo que no se dijo, no inventar datos, copiar sin corregir una fecha que ya viene como `AAAA-MM-DD` (para que la API la valide) y no afirmar que una reserva quedó hecha antes de la confirmación.

**Contexto.** En cada turno se envía a Groq el mensaje del sistema, todos los turnos anteriores y el mensaje nuevo. Groq no recuerda nada por sí mismo: la memoria es el historial que Python vuelve a enviar.

## 5. Conversación

**Roles del historial.**

| Rol | Contenido |
|---|---|
| `system` | Instrucciones de BarberBot (una sola vez, al inicio) |
| `user` | Lo que escribe la persona |
| `assistant` | El plan JSON interpretado, o el registro `{"plan": ..., "respuesta": ...}` de una operación ya ejecutada |

**Funciones principales.**

| Función | Qué hace |
|---|---|
| `nuevo_historial()` | Crea el historial con el mensaje del sistema |
| `procesar_turno()` | Interpreta un mensaje y devuelve resultado, historial nuevo y plan |
| `normalizar_plan()` | Valida la acción y limpia los campos (hora `HH:MM`, servicio en minúscula, código en mayúscula) |
| `faltantes()` | Calcula qué datos faltan según `REQUERIDOS` |
| `plan_previo()` y `fusionar()` | Recuperan del plan incompleto anterior los datos que el modelo no repitió |
| `ultimo_codigo()` | Reutiliza el código de la reserva más reciente para modificar o cancelar |
| `ejecutar()` | Envía el plan a FastAPI; las escrituras exigen `confirmar=True` |

**Flujo de un turno** (`procesar_turno()`):

1. Se envía el historial más el mensaje nuevo a Groq y se obtiene el plan.
2. Se completa con los datos de un plan incompleto anterior.
3. Si el servicio no existe en el catálogo, se vuelve a pedir.
4. Si faltan datos, el bot los pide y el plan queda guardado en el historial.
5. Las consultas (servicios, disponibilidad, reservas) se ejecutan de inmediato.
6. Crear, modificar y cancelar generan un **resumen** y esperan la confirmación.

**Sesiones.** El estado de cada ventana del navegador es un `gr.State` con tres partes: `historial` (lo que se envía a Groq), `pantalla` (lo que ve la persona) y `pendiente` (la operación esperando confirmación). Dos ventanas no comparten conversación.

**Confirmación, descarte y reinicio.**

- **Confirmar operación:** ejecuta el plan pendiente con `ejecutar(plan, confirmar=True)` y guarda el resultado en el historial.
- **Descartar solicitud:** elimina la operación pendiente sin llamar a la API; no se crea ninguna fila.
- **Reiniciar conversación:** crea un estado nuevo; el historial empieza de cero y las reservas guardadas no cambian.
- Mientras hay una operación pendiente, la interfaz no acepta mensajes nuevos hasta confirmarla o descartarla.

**Errores.** Si algo falla antes de terminar el turno, se lanza la excepción y el historial recibido queda intacto: un turno fallido no se guarda como respuesta correcta. Los errores HTTP de FastAPI se muestran con su detalle (por ejemplo, que el intervalo se cruza), y la persona puede corregir o descartar.

## 6. API y persistencia

**Endpoints.**

| Método | Ruta | Operación | Errores |
|---|---|---|---|
| GET | `/health` | Estado del servicio | |
| GET | `/api/servicios` | Catálogo | |
| GET | `/api/disponibilidad?fecha=&servicio=` | Horas libres | 422 |
| GET | `/api/reservas` | Listar | |
| GET | `/api/reservas/{codigo}` | Consultar | 404 |
| POST | `/api/reservas` | Crear (requiere `confirmada: true`) | 400, 409, 422 |
| PUT | `/api/reservas/{codigo}` | Modificar | 404, 409, 422 |
| DELETE | `/api/reservas/{codigo}` | Cancelar | 404, 409 |

**Tabla `reservas`.**

| Campo | Tipo | Restricción |
|---|---|---|
| `codigo` | TEXT | Clave primaria (8 caracteres generados automáticamente) |
| `cliente` | TEXT | No nulo |
| `servicio` | TEXT | No nulo |
| `fecha` | TEXT | No nulo, formato `AAAA-MM-DD` |
| `hora` | TEXT | No nulo, formato `HH:MM` |
| `duracion_minutos` | INTEGER | No nulo, mayor que 0 |
| `estado` | TEXT | Solo `activa` o `cancelada` |

Hay un índice `idx_fecha_estado` sobre `(fecha, estado)` para acelerar la búsqueda de reservas activas de un día.

**Operaciones y SQL.**

| Operación | SQL |
|---|---|
| Comprobar cruces | `SELECT hora, duracion_minutos FROM reservas WHERE fecha=? AND estado='activa' AND codigo<>?` |
| Crear | `INSERT INTO reservas VALUES (?, ?, ?, ?, ?, ?, ?)` |
| Modificar | `UPDATE reservas SET servicio=?, fecha=?, hora=?, duracion_minutos=? WHERE codigo=?` |
| Cancelar | `UPDATE reservas SET estado='cancelada' WHERE codigo=?` |
| Consultar | `SELECT ... FROM reservas WHERE codigo=?` |
| Listar | `SELECT ... FROM reservas` |

Todas las consultas son parametrizadas (`?`): el texto de la persona nunca se concatena dentro del SQL.

## 7. Disponibilidad

- **Horario:** de 09:00 a 18:00, de lunes a sábado, con citas cada 30 minutos (`negocio.json`).
- **Duración:** una reserva ocupa desde su hora de inicio hasta el final de su servicio. La duración se guarda en la fila, así que cambiar el catálogo no altera las reservas ya hechas.
- **Cruce de intervalos:** dos reservas se cruzan si `inicio_nuevo < fin_existente` y `fin_nuevo > inicio_existente`. Terminar justo cuando otra empieza no es cruce. Solo cuentan las reservas `activa`.
- **Horas ofrecidas:** solo aquellas donde el servicio completo cabe antes del cierre y no se cruza con una reserva activa.
- **Transacción:** al crear o modificar, la comprobación del cruce y el guardado ocurren dentro de una misma transacción abierta con `BEGIN IMMEDIATE`. Si dos personas piden el mismo intervalo a la vez, la segunda espera, vuelve a leer las reservas con la primera ya guardada, detecta el cruce y recibe un `409`. Si hay un error, se hace `ROLLBACK`.
- **Cancelación:** cambia el estado a `cancelada`, libera el intervalo y conserva el histórico.

Ejemplo: con un `corte_barba` (60 min) reservado a las 10:00, ocupa de 10:00 a 11:00. Un `corte` a las 10:30 se rechaza con `409`; uno a las 11:00 se acepta.

## 8. Evolución del proyecto durante el corte

> Completar las fechas reales, quién participó en cada avance y enlazar las capturas o cambios del repositorio que lo respaldan.

| Avance | Fecha real | Qué cambió | Participaron | Dificultad | Cómo se comprobó | Soporte |
|---|---|---|---|---|---|---|
| 1. Primera llamada al modelo | Por completar | `consulta_llm.py` envía el mensaje a Groq y recibe un plan JSON | Por completar | La clave se pegó mal y Groq respondió `HTTP 400` (sección 11) | Se listaron los modelos con `listar_modelos_groq.py` | [Clase 3](bitacoras_previas/C03_2026-10-05_Chatbot_con_memoria_y_FastAPI.md) |
| 2. Conversación con historial | Por completar | `chatbot_memoria.py`: prompt, roles, historial, `REQUERIDOS`, fusión del plan y confirmación | Por completar | Datos que se perdían entre turnos | Prueba `test_solicitud_en_varios_turnos` | [Clase 3](bitacoras_previas/C03_2026-10-05_Chatbot_con_memoria_y_FastAPI.md) |
| 3. API de reservas | Por completar | `main.py`: endpoints, validación y códigos 404, 409 y 422 | Por completar | Por completar | `/docs` y pruebas de la API | [Clase 3](bitacoras_previas/C03_2026-10-05_Chatbot_con_memoria_y_FastAPI.md) |
| 4. Interfaz Gradio | Por completar | `app_gradio.py`: chat, estado por sesión, confirmar, descartar, reiniciar y tabla de reservas | Por completar | Por completar | Dos ventanas con conversaciones separadas | [Clase 4](bitacoras_previas/C04_2026-10-19_Vista_Gradio_y_SQLite.md) |
| 5. SQLite y disponibilidad | Por completar | `almacen_sqlite.py`: tabla, intervalos, `BEGIN IMMEDIATE` y migración | Por completar | Evitar reservas simultáneas sobre el mismo intervalo | Prueba con 8 hilos: una reserva aceptada y siete conflictos | [Clase 4](bitacoras_previas/C04_2026-10-19_Vista_Gradio_y_SQLite.md) |
| 6. Docker y pruebas automáticas | Por completar | `Dockerfile`, `docker-compose.yml` y 27 pruebas con `pytest` | Por completar | Por completar | `pytest -q` y `docker compose up --build` | [evidencias](evidencias/) |

## 9. Decisiones técnicas importantes

| Decisión | Razón | Alternativa descartada |
|---|---|---|
| **Separar conversación y negocio:** `chatbot_memoria.py` decide qué pedir y confirmar; FastAPI valida y ejecuta | El modelo puede equivocarse; la regla de negocio (cruces, horario) no debe depender de él | Dejar que el modelo decida si una hora está libre |
| **Organizar funciones por responsabilidad:** interfaz, conversación, peticiones, API y almacén en archivos distintos | Cada parte se prueba y se explica por separado | Un único archivo con toda la lógica |
| **Guardar la duración de cada servicio en la reserva** | La disponibilidad se calcula con intervalos y las reservas antiguas no cambian si se modifica el catálogo | Calcular la duración a partir del catálogo cada vez |
| **Cancelar con el estado `cancelada`, sin borrar la fila** | Libera el intervalo y conserva el histórico | Eliminar la fila |
| **Comprobar y guardar en una sola transacción (`BEGIN IMMEDIATE`)** | Evita que dos personas ocupen el mismo intervalo | Comprobar y guardar en consultas separadas |
| **Exigir confirmación antes de escribir** | El modelo propone y la persona decide; la API vuelve a validar | Ejecutar apenas el modelo interpreta |
| **Una conversación por sesión (`gr.State`)** | Evita mezclar conversaciones de personas distintas | Variables globales o un archivo de memoria compartido |
| **`negocio.json` como fuente única** | Cambiar un servicio no exige tocar el código | Repetir los servicios en varios archivos |
| **Secretos solo en variables de entorno** | La clave no entra al repositorio ni a la imagen de Docker | Escribir la clave en un archivo |

## 10. Pruebas

Las pruebas automáticas se ejecutan con `python -m pytest -q` (27 pruebas, sin red ni clave). Las pruebas manuales se hacen desde Gradio y la API. **Los resultados obtenidos de las pruebas manuales deben completarlos los integrantes con lo observado.**

| Prueba | Entrada o acción | Resultado esperado | Resultado obtenido | Evidencia | Estado |
|---|---|---|---|---|---|
| Conversación en varios turnos | «Quiero un corte, soy Laura» y luego «Para el AAAA-MM-DD a las 10:00» | El segundo turno conserva nombre y servicio y muestra el resumen | Automática: pasa (`test_solicitud_en_varios_turnos`). Gradio: Por completar | `evidencias/02_multiples_turnos.png` | Por completar |
| Consulta de servicios | «¿Qué servicios tienen?» | Lista de servicios con precio y duración | Por completar | `evidencias/01_servicios_chat.png` | Por completar |
| Crear reserva | Confirmar el resumen | Fila nueva con estado `activa` y un código | Automática: pasa (`test_crear_y_consultar`). Gradio: Por completar | `evidencias/03_confirmacion_y_codigo.png`, `evidencias/04_fila_sqlite.png` | Por completar |
| Intervalo ocupado | `corte_barba` a las 10:00 y luego `corte` a las 10:30 | HTTP 409 y no se crea la segunda fila | Automática: pasa (`test_cruce_de_intervalos_se_rechaza`). Gradio: Por completar | `evidencias/05_cruce_409.png` | Por completar |
| Reserva contigua | `corte` a las 11:00 | Se acepta (no hay cruce) | Automática: pasa (`test_reserva_contigua_se_acepta`). Gradio: Por completar | `evidencias/06_reserva_contigua.png` | Por completar |
| Disponibilidad | Consultar las horas libres antes y después de reservar | Las horas ocupadas desaparecen | Automática: pasa (`test_disponibilidad_antes_y_despues`). Gradio: Por completar | `evidencias/07_disponibilidad.png` | Por completar |
| Modificar | Cambiar a una hora libre y a una ocupada | Libre: cambia. Ocupada: 409 y se conservan los datos anteriores | Automática: pasa (dos pruebas). Gradio: Por completar | `evidencias/08_modificar.png` | Por completar |
| Cancelar | Cancelar una reserva y consultar la disponibilidad | Estado `cancelada` y el intervalo vuelve a estar libre | Automática: pasa (`test_cancelar_libera_el_intervalo`). Gradio: Por completar | `evidencias/09_cancelar.png` | Por completar |
| Descartar | Preparar una reserva y pulsar «Descartar solicitud» | No se crea ninguna fila | Automática: pasa (`test_interfaz_reiniciar_y_descartar`). Gradio: Por completar | `evidencias/10_descartar.png` | Por completar |
| Dos sesiones y reinicio | Dos ventanas (una privada) y «Reiniciar conversación» | Conversaciones separadas; el reinicio limpia el historial y conserva las reservas | Por completar | `evidencias/11_dos_sesiones.png` | Por completar |
| Concurrencia | 8 solicitudes simultáneas al mismo intervalo | Una aceptada y siete conflictos | Automática: pasa (`test_solo_una_reserva_gana_el_mismo_intervalo`) | `evidencias/13_pytest.png` | Pasa |
| Persistencia | Reiniciar la API y listar las reservas | Las filas y sus estados siguen guardados | Automática: pasa (`test_persistencia_tras_reiniciar`). Manual: Por completar | `evidencias/12_persistencia.png` | Por completar |
| Errores | Fecha `2030-99-14`, domingo, fuera de horario, servicio desconocido | HTTP 422 (o nueva petición del servicio) y se puede continuar | Automática: pasa (pruebas de datos inválidos) | `evidencias/13_pytest.png` | Pasa |

**Casos que fallaron y su estado.** La clave de Groq pegada con `Ctrl + V` en un campo oculto produjo `HTTP 400` (sección 11); está **resuelto**. Cualquier otro fallo observado por el equipo debe registrarse aquí: **Por completar**.

## 11. Errores resueltos

| Problema | Causa | Solución | Verificación |
|---|---|---|---|
| Groq respondía `HTTP Error 400: Bad Request` | La variable `GROQ_API_KEY` tenía un solo carácter de control (`\x16`), porque `Ctrl + V` no pega dentro de `Read-Host -AsSecureString` | Se pegó la clave con clic derecho, se revisó su largo y prefijo `gsk_` y se creó una clave nueva | `listar_modelos_groq.py` mostró la lista de modelos |
| Se perdían datos entre turnos | El modelo no siempre repite lo dicho antes | `plan_previo()` y `fusionar()` completan el plan | `test_solicitud_en_varios_turnos` |
| Un turno con error podía quedar en el historial | El historial se actualizaba antes de saber si la API respondió | `procesar_turno()` devuelve el historial nuevo solo al terminar | `test_error_de_api_no_modifica_el_historial` |
| El modelo corregía una fecha inválida | Tiende a «arreglar» datos | El prompt indica copiar la fecha tal cual para que la API la rechace con 422 | Consulta con `2030-99-14` |
| Dos personas podían reservar el mismo intervalo | Comprobar y guardar por separado deja una ventana | `BEGIN IMMEDIATE` y comprobación dentro de la transacción | Prueba con 8 hilos |
| Los datos de ejemplo chocaban entre sí | `reservas.json` y `datos_prueba.py` usaban el mismo día | `reservas.json` usa fechas pasadas (históricas) | `test_migracion_y_datos_de_prueba_no_chocan` |
| `uvicorn --reload` se reiniciaba por archivos de `.venv` | Vigila todos los archivos del proyecto | Se ejecuta la API sin `--reload` | La API se mantiene estable |
| `reservas.db` no se abre en un editor de texto | Es un archivo binario | Se consulta con `python -m sqlite3`, `/api/reservas` o la tabla de Gradio | Se listan las filas |

## 12. Limitaciones y mejoras pendientes

**Limitaciones actuales.**

- **Sin autenticación:** el cliente se identifica solo por su nombre; cualquiera que conozca un código puede consultar, modificar o cancelar esa reserva.
- **Una sola agenda:** no hay varios barberos. Un intervalo ocupado bloquea a toda la barbería.
- **El historial no persiste:** vive en la sesión; al recargar la página o cerrar Gradio se pierde (las reservas sí se conservan).
- **Dependencia de Groq:** si el servicio o el modelo fallan, el chat no puede interpretar mensajes. No hay reintentos automáticos.
- **Interpretación del modelo:** puede equivocarse en fechas relativas o nombres; por eso siempre se muestra un resumen antes de ejecutar.
- **Sin zonas horarias ni festivos:** se usa la fecha del equipo y los días de atención fijos de `negocio.json`.
- **No hay borrado definitivo:** cancelar conserva la fila.
- **Sin notificaciones:** no hay recordatorios por correo o mensaje.
- **Docker:** la configuración existe, pero su despliegue completo debe verificarse: **Por completar**.
- **SQLite:** adecuado para este tamaño; con muchos usuarios simultáneos convendría un servidor de base de datos.

**Mejoras pendientes.**

- Autenticación o verificación del cliente antes de modificar o cancelar.
- Varios barberos, cada uno con su agenda.
- Guardar el historial de la conversación.
- Recordatorios de las citas.
- Reintentos y mensajes más claros cuando falle el modelo.

## 13. Comparación con Flowise

> Completar la columna de Flowise con cómo estaba construido el chatflow del equipo.

| Aspecto | Con Flowise y JSON | Con Python, Gradio y SQLite | Responsabilidad que asumió el equipo |
|---|---|---|---|
| Prompt y contexto | Por completar | `instrucciones_sistema()` arma el prompt con la fecha, el horario y el catálogo | Redactar y mantener las reglas del modelo |
| Memoria | Por completar | Historial propio por sesión, enviado completo en cada turno | Decidir qué se guarda y cómo se recupera |
| Salida del modelo | Por completar | JSON fijo validado con `normalizar_plan()` | Validar cada campo antes de usarlo |
| Reglas del negocio | Por completar | En FastAPI y SQLite: horario, duración y cruces | Programar y probar las reglas |
| Persistencia | JSON | SQLite con transacciones | Diseñar la tabla y evitar reservas simultáneas |
| Interfaz | Por completar | Gradio con botones de confirmar, descartar y reiniciar | Manejar el estado por sesión |
| Errores | Por completar | HTTP 404, 409 y 422 con su detalle | Informar el problema y permitir continuar |
| Pruebas | Por completar | 27 pruebas automáticas | Escribir y mantener las pruebas |

En resumen, el cambio principal fue pasar de configurar un flujo visual a **escribir y asumir en código** el control de la conversación, la validación, la persistencia y las pruebas.

## 14. Uso de inteligencia artificial

| Herramienta | Objetivo | Qué se utilizó | Cómo se verificó | Qué se modificó |
|---|---|---|---|---|
| Claude (Anthropic) | Construir la estructura del proyecto, guiar la ejecución, resolver errores y redactar la documentación en borrador | Código del proyecto, pruebas, instrucciones y borradores de documentos | Se ejecutaron las 27 pruebas, se probaron la API y el chat, y se contrastaron los resultados con SQLite | Por completar con los cambios del equipo |
| Groq | Interpretar los mensajes y devolver planes en JSON | Modelo: Por completar | Se revisaron los planes en el historial de la interfaz | Se adaptó el prompt a la barbería |

La inteligencia artificial fue un apoyo: el equipo debe poder explicar cada decisión de este documento. La disponibilidad y las reservas las resuelven Python, FastAPI y SQLite, no el modelo.

## 15. Aprendizajes

1. Groq interpreta el lenguaje, pero las reglas del negocio deben vivir en el código y en la base de datos.
2. Guardar la conversación no significa que el modelo la recuerde: hay que enviarla en cada turno.
3. Una reserva ocupa un intervalo, no solo una hora de inicio.
4. Comprobar y guardar en la misma transacción evita reservas simultáneas.
5. Pedir confirmación y volver a validar en la API protege contra errores del modelo.
6. Las pruebas automáticas permiten comprobar las reglas cada vez que cambia el código.
7. Las claves se manejan como variables de entorno y no se publican.

## 16. Evidencias y enlaces

Las capturas están en [`evidencias/`](evidencias/) y su lista de nombres en [`evidencias/LEEME.md`](evidencias/LEEME.md). Cada una debe tener su pie: **qué se probaba, qué ocurrió y qué demuestra**.

| Evidencia | Archivo | Pie (Por completar) |
|---|---|---|
| Servicios en el chat | `evidencias/01_servicios_chat.png` | |
| Solicitud en varios turnos | `evidencias/02_multiples_turnos.png` | |
| Resumen y reserva creada | `evidencias/03_confirmacion_y_codigo.png` | |
| Fila en SQLite | `evidencias/04_fila_sqlite.png` | |
| Rechazo por cruce (409) | `evidencias/05_cruce_409.png` | |
| Reserva contigua aceptada | `evidencias/06_reserva_contigua.png` | |
| Disponibilidad antes y después | `evidencias/07_disponibilidad.png` | |
| Modificar | `evidencias/08_modificar.png` | |
| Cancelar | `evidencias/09_cancelar.png` | |
| Descartar | `evidencias/10_descartar.png` | |
| Dos sesiones | `evidencias/11_dos_sesiones.png` | |
| Persistencia tras reiniciar | `evidencias/12_persistencia.png` | |
| Pruebas automáticas | `evidencias/13_pytest.png` | |
| Documentación de la API | `evidencias/14_api_docs.png` | |

## 17. Revisión antes de entregar

- [ ] El enlace de GitHub abre y contiene la versión final.
- [ ] El README permite ejecutar una copia nueva del proyecto.
- [ ] Esta bitácora no tiene campos «Por completar».
- [ ] Las evidencias están en `docs/evidencias/` y cada una tiene su pie.
- [ ] El PDF fue regenerado con las capturas reales.
- [ ] Los archivos compartidos usan datos ficticios y no incluyen claves.
- [ ] Todos los integrantes pueden explicar el recorrido de una solicitud.
