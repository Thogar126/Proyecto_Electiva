"""Genera docs/Presentacion_Segundo_Corte.pdf.

Uso (desde la carpeta raíz del repositorio):
    python docs/generar_presentacion.py

Si existe una captura en docs/evidencias/ con el nombre esperado, se inserta en su
página; si no, se dibuja un recuadro «CAPTURA PENDIENTE». Para completar el PDF basta
con guardar las capturas con sus nombres (ver docs/evidencias/LEEME.md) y volver a
ejecutar este script. Necesita reportlab (requirements-dev.txt).
"""

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from reportlab.platypus import Frame, KeepInFrame, Paragraph, Table, TableStyle

BASE = Path(__file__).resolve().parent
EVIDENCIAS = BASE / "evidencias"
SALIDA = BASE / "Presentacion_Segundo_Corte.pdf"

REPO = "&lt;URL_DEL_REPOSITORIO&gt;"  # cambia esta línea por el enlace real
INTEGRANTES = ["Juan Sebastián Rodríguez", "Juan José Anduquia", "David Hurtado", "Thomas García"]

W, H = 960, 540
NAVY = colors.HexColor("#102a4c")
AZUL = colors.HexColor("#0077b6")
CIAN = colors.HexColor("#e3f4fa")
GRIS = colors.HexColor("#64768b")
VERDE = colors.HexColor("#2a9d6f")
ROJO = colors.HexColor("#d1495b")
BORDE = colors.HexColor("#cbdce8")

ESTILO = ParagraphStyle("base", fontName="Helvetica", fontSize=15, leading=20, textColor=NAVY)


def estilo(tam=15, **extra):
    return ParagraphStyle("x", parent=ESTILO, fontSize=tam, leading=tam * 1.33, **extra)


class Presentacion:
    def __init__(self):
        self.c = canvas.Canvas(str(SALIDA), pagesize=(W, H))
        self.c.setTitle("BarberBot · Presentación del segundo corte")
        self.c.setAuthor(", ".join(INTEGRANTES))
        self.numero = 0
        self.pendientes = []

    # ---------- piezas básicas ----------
    def pagina(self, titulo, etiqueta=""):
        self.numero += 1
        c = self.c
        c.setFillColor(colors.HexColor("#f8fbfd"))
        c.rect(0, 0, W, H, stroke=0, fill=1)
        c.setFillColor(NAVY)
        c.rect(0, H - 62, W, 62, stroke=0, fill=1)
        if etiqueta:
            c.setFillColor(colors.HexColor("#7fd3ee"))
            c.setFont("Helvetica-Bold", 10)
            c.drawString(40, H - 22, etiqueta.upper())
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 25)
        c.drawString(40, H - 50, titulo)
        c.setStrokeColor(BORDE)
        c.line(40, 30, W - 40, 30)
        c.setFillColor(GRIS)
        c.setFont("Helvetica", 10)
        c.drawString(40, 16, "BarberBot · Segundo corte · Creación de chatbots")
        c.drawRightString(W - 40, 16, f"{self.numero}")

    def cerrar_pagina(self):
        self.c.showPage()

    def texto(self, items, x, y_top, w, h, tam=15, vineta=True, espacio=6, encabezado=False):
        piezas = []
        for i, item in enumerate(items):
            con_vineta = vineta and not (encabezado and i == 0)
            piezas.append(Paragraph(item, estilo(tam, spaceAfter=espacio),
                                    bulletText="•" if con_vineta else None))
        marco = Frame(x, y_top - h, w, h, leftPadding=0, rightPadding=0, topPadding=0,
                      bottomPadding=0, showBoundary=0)
        marco.addFromList([KeepInFrame(w, h, piezas, mode="shrink")], self.c)

    def tabla(self, filas, x, y_top, anchos, tam=12, encabezado=True):
        datos = []
        for i, fila in enumerate(filas):
            est = estilo(tam, textColor=colors.white if (encabezado and i == 0) else NAVY,
                         fontName="Helvetica-Bold" if (encabezado and i == 0) else "Helvetica")
            datos.append([Paragraph(celda, est) for celda in fila])
        t = Table(datos, colWidths=anchos)
        reglas = [("VALIGN", (0, 0), (-1, -1), "TOP"),
                  ("LINEBELOW", (0, 0), (-1, -1), 0.5, BORDE),
                  ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]
        if encabezado:
            reglas.append(("BACKGROUND", (0, 0), (-1, 0), AZUL))
        t.setStyle(TableStyle(reglas))
        _, alto = t.wrapOn(self.c, sum(anchos), 1000)
        t.drawOn(self.c, x, y_top - alto)
        return alto

    def caja(self, texto, x, y_top, w, h, tam=13):
        c = self.c
        c.setFillColor(CIAN)
        c.setStrokeColor(colors.HexColor("#1da9ca"))
        c.rect(x, y_top - h, w, h, stroke=0, fill=1)
        c.setFillColor(colors.HexColor("#1da9ca"))
        c.rect(x, y_top - h, 5, h, stroke=0, fill=1)
        self.texto([texto], x + 16, y_top - 8, w - 28, h - 16, tam=tam, vineta=False, espacio=0)

    def captura(self, archivo, x, y_top, w, h, pie):
        """Inserta la captura si existe; si no, dibuja un recuadro pendiente. `pie` va debajo."""
        c = self.c
        ruta = EVIDENCIAS / archivo
        y = y_top - h
        if ruta.exists():
            imagen = ImageReader(str(ruta))
            iw, ih = imagen.getSize()
            escala = min(w / iw, h / ih)
            dw, dh = iw * escala, ih * escala
            c.setStrokeColor(BORDE)
            c.rect(x, y, w, h, stroke=1, fill=0)
            c.drawImage(imagen, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh, mask="auto")
        else:
            self.pendientes.append(archivo)
            c.setStrokeColor(GRIS)
            c.setDash(5, 4)
            c.setFillColor(colors.HexColor("#eef4f8"))
            c.rect(x, y, w, h, stroke=1, fill=1)
            c.setDash()
            c.setFillColor(GRIS)
            c.setFont("Helvetica-Bold", 12)
            c.drawCentredString(x + w / 2, y + h / 2 + 8, "CAPTURA PENDIENTE")
            c.setFont("Helvetica", 11)
            c.drawCentredString(x + w / 2, y + h / 2 - 10, f"docs/evidencias/{archivo}")
        self.texto([pie], x, y - 8, w, max(50, y - 44), tam=13, vineta=False, espacio=2)

    def flecha(self, x1, y1, x2, y2):
        c = self.c
        c.setStrokeColor(AZUL)
        c.setFillColor(AZUL)
        c.setLineWidth(1.6)
        c.line(x1, y1, x2, y2)
        c.setLineWidth(1)
        horizontal = abs(y2 - y1) < abs(x2 - x1)
        p = c.beginPath()
        if horizontal:
            s = 1 if x2 > x1 else -1
            p.moveTo(x2, y2)
            p.lineTo(x2 - 9 * s, y2 + 5)
            p.lineTo(x2 - 9 * s, y2 - 5)
        else:
            s = 1 if y2 > y1 else -1
            p.moveTo(x2, y2)
            p.lineTo(x2 - 5, y2 - 9 * s)
            p.lineTo(x2 + 5, y2 - 9 * s)
        p.close()
        c.drawPath(p, stroke=0, fill=1)

    def bloque(self, x, y, w, h, titulo, detalle, relleno=AZUL):
        c = self.c
        c.setFillColor(relleno)
        c.roundRect(x, y, w, h, 8, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 14)
        c.drawCentredString(x + w / 2, y + h - 24, titulo)
        marco = Frame(x + 6, y + 4, w - 12, h - 34, leftPadding=0, rightPadding=0, topPadding=0,
                      bottomPadding=0, showBoundary=0)
        marco.addFromList([KeepInFrame(w - 12, h - 34, [Paragraph(
            detalle, estilo(11.5, textColor=colors.white, alignment=1))], mode="shrink")], c)

    # ---------- páginas ----------
    def portada(self):
        self.numero += 1
        c = self.c
        c.setFillColor(NAVY)
        c.rect(0, 0, W, H, stroke=0, fill=1)
        c.setFillColor(colors.HexColor("#7fd3ee"))
        c.setFont("Helvetica-Bold", 13)
        c.drawString(60, 440, "PROYECTO DEL SEGUNDO CORTE · CREACIÓN DE CHATBOTS")
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 64)
        c.drawString(60, 360, "BarberBot")
        c.setFont("Helvetica", 24)
        c.drawString(60, 320, "Chatbot para reservar citas en una barbería")
        c.setFont("Helvetica", 14)
        c.drawString(60, 280, "Electiva II · EAM-2026II")
        c.setFont("Helvetica-Bold", 14)
        c.drawString(60, 235, "Integrantes")
        c.setFont("Helvetica", 14)
        for i, nombre in enumerate(INTEGRANTES):
            c.drawString(60, 212 - i * 22, nombre)
        marco = Frame(60, 60, 840, 50, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        marco.addFromList([Paragraph(f"Repositorio: {REPO}",
                                     estilo(13, textColor=colors.HexColor("#7fd3ee")))], c)
        self.cerrar_pagina()

    def contexto(self):
        self.pagina("Contexto y problema", "Identificación")
        self.texto(["<b>El negocio.</b> Una barbería ofrece cuatro servicios con distinta duración y precio, "
                    "y atiende de lunes a sábado, de 9:00 a. m. a 6:00 p. m., con citas cada 30 minutos."],
                   40, 450, 880, 60, tam=17, vineta=False)
        self.tabla([["Servicio", "Duración", "Precio"],
                    ["Corte de cabello", "30 min", "$25.000"],
                    ["Arreglo de barba", "30 min", "$15.000"],
                    ["Corte + barba", "60 min", "$35.000"],
                    ["Tinte de cabello", "90 min", "$60.000"]],
                   40, 385, [220, 110, 110], tam=15)
        self.texto(["<b>El problema.</b> Como cada servicio dura un tiempo distinto, agendar a mano es "
                    "propenso a errores:",
                    "dos citas pueden <b>cruzarse</b>;", "una reserva puede <b>perderse</b>;",
                    "la persona no sabe <b>qué horas están libres</b>."],
                   540, 385, 380, 230, tam=17, encabezado=True)
        self.caja("<b>Quién lo usa:</b> las personas que quieren reservar una cita. Todos los datos del "
                  "proyecto (nombres, reservas) son ficticios y de prueba.", 40, 170, 880, 56)
        self.cerrar_pagina()

    def solucion(self):
        self.pagina("Solución y alcance", "Qué resuelve")
        self.texto(["<b>BarberBot es un chatbot:</b> una persona escribe en español lo que necesita y el "
                    "sistema la ayuda a hacerlo, sin cruzar horarios."], 40, 450, 880, 50, tam=17, vineta=False)
        self.texto(["<b>Lo que hace</b>", "Muestra servicios, precios y duraciones.",
                    "Calcula las horas libres de un día para un servicio.",
                    "Pide los datos que faltan, aunque lleguen en varios mensajes.",
                    "Crea, consulta, modifica y cancela reservas.",
                    "Pide confirmación antes de guardar o cambiar algo.",
                    "Rechaza los horarios que se cruzan con otra reserva."],
                   40, 390, 430, 280, tam=16.5, encabezado=True)
        self.texto(["<b>Lo que todavía no hace</b>",
                    "No verifica quién es la persona: se identifica solo con su nombre y un código.",
                    "Tiene una sola agenda (no hay varios barberos).",
                    "No envía recordatorios de las citas.",
                    "No guarda el historial del chat al cerrar la página (las reservas sí se guardan)."],
                   510, 390, 410, 280, tam=16.5, encabezado=True)
        self.cerrar_pagina()

    def herramientas(self):
        self.pagina("Herramientas y para qué sirve cada una", "Términos")
        self.tabla([["Herramienta", "Qué es", "Su tarea en BarberBot"],
                    ["Python", "Lenguaje de programación", "Coordina la conversación y revisa los datos"],
                    ["Gradio", "Biblioteca para crear pantallas web", "Muestra el chat y los botones"],
                    ["Groq (modelo de lenguaje)", "Servicio de inteligencia artificial que entiende texto",
                     "Convierte el mensaje en un plan con la acción y los datos"],
                    ["JSON", "Formato de datos escrito como texto", "Da forma al plan: acción, cliente, servicio, fecha, hora"],
                    ["FastAPI", "Biblioteca para crear una API", "Recibe y ejecuta las operaciones de reservas"],
                    ["API", "Puerta de entrada de un programa", "Permite pedir «consultar» o «guardar» una reserva"],
                    ["SQLite", "Base de datos guardada en un archivo", "Conserva las reservas en <i>reservas.db</i>"],
                    ["HTTP 409", "Código de respuesta que significa «conflicto»", "Avisa que el horario se cruza con otra reserva"]],
                   40, 455, [200, 320, 360], tam=14)
        self.cerrar_pagina()

    def funcionamiento(self):
        self.pagina("Cómo funciona el sistema", "Funcionamiento")
        y = 335
        self.bloque(30, y, 140, 100, "Persona", "Escribe lo que necesita", NAVY)
        self.bloque(205, y, 150, 100, "Gradio", "Pantalla del chat y botones")
        self.bloque(390, y, 170, 100, "Python", "Conversación: historial, datos que faltan y confirmación")
        self.bloque(595, y, 150, 100, "FastAPI", "Operaciones del negocio y validación")
        self.bloque(780, y, 150, 100, "SQLite", "Guarda las reservas en reservas.db", NAVY)
        self.bloque(390, 205, 170, 90, "Groq", "Entiende el mensaje y devuelve un plan JSON", colors.HexColor("#2a6f97"))
        for x1, x2 in [(170, 205), (355, 390), (560, 595), (745, 780)]:
            self.flecha(x1, y + 50, x2, y + 50)
        self.flecha(475, y, 475, 295)
        self.texto(["La persona escribe en Gradio. <b>Python</b> envía el historial a <b>Groq</b>, que devuelve un plan.",
                    "Python revisa que no falte ningún dato y muestra un resumen para <b>confirmar</b>.",
                    "Al confirmar, <b>FastAPI</b> valida el horario y <b>SQLite</b> guarda la reserva.",
                    "<b>Groq nunca decide si una hora está libre:</b> eso lo calcula FastAPI con la base de datos."],
                   40, 185, 880, 150, tam=13.5)
        self.cerrar_pagina()

    def recorrido(self):
        self.pagina("Recorrido de una solicitud completa", "Cómo lo usa una persona")
        self.texto(["<b>1.</b> La persona escribe: <i>«Quiero un corte, me llamo Laura»</i>. El bot pide los datos que faltan: la fecha y la hora.",
                    "<b>2.</b> Responde: <i>«Para el día elegido a las 10:00»</i>. El bot conserva el nombre y el servicio, y muestra un <b>resumen</b> con los botones Confirmar y Descartar.",
                    "<b>3.</b> Al pulsar <b>Confirmar operación</b>, FastAPI comprueba que el intervalo esté libre, lo guarda en SQLite y devuelve un <b>código</b> de reserva.",
                    "<b>4.</b> Con ese código la persona puede consultar, modificar o cancelar su reserva."],
                   40, 450, 420, 400, tam=15, vineta=False, espacio=10)
        self.captura("02_multiples_turnos.png", 490, 452, 430, 140,
                     "<b>Se probó:</b> una solicitud en dos mensajes. <b>Resultado:</b> el bot conserva el nombre y el servicio y pide solo lo que falta. <b>Demuestra:</b> que la conversación recuerda los datos.")
        self.captura("03_confirmacion_y_codigo.png", 490, 232, 430, 120,
                     "<b>Se probó:</b> el resumen y la confirmación. <b>Resultado:</b> la reserva queda creada con su código. <b>Demuestra:</b> que nada se guarda sin confirmar.")
        self.cerrar_pagina()

    def reglas(self):
        self.pagina("Reglas del negocio: disponibilidad y cruces", "Reglas")
        self.texto(["<b>Horario:</b> lunes a sábado, de 9:00 a 18:00, con citas cada 30 minutos.",
                    "<b>Duración:</b> una reserva ocupa todo su intervalo, no solo su hora de inicio.",
                    "<b>Cruce:</b> dos reservas se cruzan si una empieza antes de que termine la otra y termina después de que la otra empieza. Terminar justo cuando otra empieza <b>no</b> es cruce.",
                    "<b>Un solo paso:</b> comprobar el horario y guardar ocurren juntos, en una <b>transacción</b>. Si dos personas piden la misma hora a la vez, solo una se acepta.",
                    "<b>Cancelar</b> libera el horario y conserva el registro."],
                   40, 450, 410, 400, tam=14.5)
        c = self.c
        c.setFillColor(NAVY)
        c.setFont("Helvetica-Bold", 13)
        c.drawString(500, 440, "Ejemplo de la tarde")
        x0, ancho = 610, 310  # 10:00 a 12:00
        for i, hora in enumerate(["10:00", "10:30", "11:00", "11:30", "12:00"]):
            x = x0 + i * ancho / 4
            c.setStrokeColor(BORDE)
            c.line(x, 195, x, 420)
            c.setFillColor(GRIS)
            c.setFont("Helvetica", 11)
            c.drawCentredString(x, 180, hora)
        filas = [("Reserva existente", "Corte + barba 60 min", 0, 2, AZUL, 380),
                 ("Intento A (10:30)", "Corte 30 min", 1, 2, ROJO, 320),
                 ("Intento B (11:00)", "Corte 30 min", 2, 3, VERDE, 260)]
        for etiqueta, texto, ini, fin, color, y in filas:
            c.setFillColor(NAVY)
            c.setFont("Helvetica-Bold", 10.5)
            c.drawRightString(600, y + 22, etiqueta)
            c.setFillColor(color)
            c.roundRect(x0 + ini * ancho / 4, y, (fin - ini) * ancho / 4, 38, 5, stroke=0, fill=1)
            c.setFillColor(colors.white)
            c.setFont("Helvetica-Bold", 10)
            c.drawCentredString(x0 + (ini + fin) / 2 * ancho / 4, y + 14, texto)
        self.texto(["<b>A</b> se rechaza (error 409): se cruza con la reserva de 10:00 a 11:00. <b>B</b> se acepta: empieza justo cuando la anterior termina."],
                   500, 150, 420, 70, tam=12.5, vineta=False)
        self.cerrar_pagina()

    def datos(self):
        self.pagina("Datos guardados: la base de datos", "Persistencia")
        self.texto(["Cada reserva es una <b>fila</b> de la tabla <i>reservas</i>, dentro del archivo <i>reservas.db</i>."],
                   40, 450, 440, 60, tam=14, vineta=False)
        self.tabla([["Campo", "Qué guarda"],
                    ["codigo", "Identificador único de 8 caracteres"],
                    ["cliente", "Nombre de la persona"],
                    ["servicio", "corte, barba, corte_barba o tinte"],
                    ["fecha y hora", "Cuándo empieza la cita"],
                    ["duracion_minutos", "Cuánto dura (se guarda para no cambiar reservas viejas)"],
                    ["estado", "<i>activa</i> o <i>cancelada</i>"]],
                   40, 400, [150, 290], tam=13)
        self.captura("04_fila_sqlite.png", 500, 450, 420, 230,
                     "<b>Se probó:</b> consultar la tabla con un SELECT. <b>Resultado:</b> la reserva confirmada aparece como una fila con estado activa. <b>Demuestra:</b> que lo que se pide en el chat queda guardado.")
        self.cerrar_pagina()

    def pruebas(self, titulo, izquierda, derecha):
        self.pagina(titulo, "Pruebas y resultados")
        self.captura(izquierda[0], 40, 456, 430, 265, izquierda[1])
        self.captura(derecha[0], 490, 456, 430, 265, derecha[1])
        self.cerrar_pagina()

    def resumen_pruebas(self):
        self.pagina("Resumen de pruebas y resultados", "Pruebas y resultados")
        self.tabla([["Prueba", "Resultado que se comprueba"],
                    ["Conversación en varios turnos", "Conserva los datos de los mensajes anteriores"],
                    ["Dos sesiones y reinicio", "Separa las conversaciones y limpia el estado al reiniciar"],
                    ["Crear, modificar y cancelar", "Guarda los cambios correctos y se ven en SQLite"],
                    ["Intervalos ocupados", "Rechaza con error 409 una reserva que se cruza con otra activa"],
                    ["Cancelación y persistencia", "Libera la disponibilidad y conserva las filas al reiniciar la API"],
                    ["Errores", "Informa el problema (fecha inválida, domingo, fuera de horario) y permite continuar"],
                    ["Pruebas automáticas", "27 pruebas con pytest, incluida una con 8 solicitudes simultáneas al mismo horario"]],
                   40, 455, [260, 620], tam=13)
        self.captura("13_pytest.png", 40, 215, 560, 115,
                     "<b>Se probó:</b> el conjunto de pruebas automáticas. <b>Resultado:</b> pasan las 27. <b>Demuestra:</b> que las reglas siguen funcionando.")
        self.cerrar_pagina()

    def evolucion(self):
        self.pagina("Evolución: de Flowise y JSON a Python, Gradio y SQLite", "Comparación")
        self.tabla([["Aspecto", "Antes: Flowise + JSON", "Ahora: Python + Gradio + SQLite"],
                    ["Conversación", "Bloques conectados en un flujo visual", "Código propio: historial, plan JSON, datos que faltan y confirmación"],
                    ["Reglas del negocio", "Configuradas junto al flujo y los datos", "FastAPI y SQLite calculan horarios, duraciones y cruces"],
                    ["Datos", "Archivo JSON", "Base SQLite con transacciones: no se cruzan ni se pierden reservas"],
                    ["Pantalla", "La que ofrece la herramienta", "Gradio, con un estado separado por sesión"],
                    ["Verificación", "Pruebas desde la herramienta", "27 pruebas automáticas y evidencias documentadas"]],
                   40, 455, [170, 300, 410], tam=14)
        self.caja("<b>Qué asumió el equipo en el código:</b> escribir el prompt, guardar y enviar el historial, "
                  "validar cada dato, calcular los intervalos, evitar reservas simultáneas, manejar los errores "
                  "y probar todo.", 40, 235, 880, 70, tam=15)
        self.cerrar_pagina()

    def cierre(self):
        self.pagina("Cierre: limitaciones, mejoras y repositorio", "Conclusión")
        self.texto(["<b>Limitaciones actuales</b>", "Sin verificación de identidad: el código es la única llave de una reserva.",
                    "Una sola agenda para toda la barbería.", "El historial del chat no se guarda entre sesiones.",
                    "Depende de que el servicio de Groq esté disponible."],
                   40, 450, 430, 230, tam=15.5, encabezado=True)
        self.texto(["<b>Mejoras pendientes</b>", "Autenticación antes de modificar o cancelar.",
                    "Varios barberos, cada uno con su agenda.", "Recordatorios de las citas.",
                    "Guardar el historial de las conversaciones."],
                   510, 450, 410, 230, tam=15.5, encabezado=True)
        self.caja(f"<b>Repositorio:</b> {REPO}<br/><b>Documentos:</b> README.md (cómo ejecutarlo) y "
                  "docs/Bitacora_Segundo_Corte.md (explicación completa, pruebas y decisiones). "
                  "Las capturas están en docs/evidencias/.", 40, 190, 880, 80, tam=13.5)
        self.cerrar_pagina()

    def construir(self):
        self.portada()
        self.contexto()
        self.solucion()
        self.herramientas()
        self.funcionamiento()
        self.recorrido()
        self.reglas()
        self.datos()
        self.pruebas("Prueba: consulta de servicios y API",
                     ("01_servicios_chat.png", "<b>Se probó:</b> preguntar «¿Qué servicios tienen?» en el chat. <b>Resultado:</b> el bot responde con la lista de servicios, precios y duraciones que entrega FastAPI. <b>Demuestra:</b> que el chat consulta datos reales de la API."),
                     ("14_api_docs.png", "<b>Se probó:</b> abrir la documentación de la API en /docs. <b>Resultado:</b> se listan los endpoints de reservas y disponibilidad. <b>Demuestra:</b> qué operaciones expone FastAPI."))
        self.pruebas("Prueba: intervalos que se cruzan",
                     ("05_cruce_409.png", "<b>Se probó:</b> pedir un corte a las 10:30 con un corte + barba reservado a las 10:00. <b>Resultado:</b> el sistema responde con error 409 y no guarda la reserva. <b>Demuestra:</b> que no se cruzan las reservas."),
                     ("06_reserva_contigua.png", "<b>Se probó:</b> pedir un corte a las 11:00, justo cuando termina la reserva anterior. <b>Resultado:</b> se acepta y queda guardada. <b>Demuestra:</b> que terminar y empezar a la misma hora no es un cruce."))
        self.pruebas("Prueba: disponibilidad y cancelación",
                     ("07_disponibilidad.png", "<b>Se probó:</b> consultar las horas libres antes y después de reservar. <b>Resultado:</b> las horas ocupadas desaparecen de la lista. <b>Demuestra:</b> que la disponibilidad usa las reservas activas."),
                     ("09_cancelar.png", "<b>Se probó:</b> cancelar una reserva y volver a consultar. <b>Resultado:</b> el estado pasa a cancelada y el horario vuelve a estar libre. <b>Demuestra:</b> que cancelar libera el intervalo."))
        self.pruebas("Prueba: modificar y descartar",
                     ("08_modificar.png", "<b>Se probó:</b> cambiar una reserva a una hora libre y a una ocupada. <b>Resultado:</b> la primera cambia; la segunda se rechaza y conserva los datos anteriores. <b>Demuestra:</b> que una modificación fallida no daña la reserva."),
                     ("10_descartar.png", "<b>Se probó:</b> preparar una reserva y pulsar Descartar. <b>Resultado:</b> no se crea ninguna fila. <b>Demuestra:</b> que solo se guarda lo que la persona confirma."))
        self.pruebas("Prueba: dos sesiones y persistencia",
                     ("11_dos_sesiones.png", "<b>Se probó:</b> dos ventanas del navegador a la vez. <b>Resultado:</b> cada una tiene su propia conversación; reiniciar una no afecta a la otra. <b>Demuestra:</b> que el estado es por sesión."),
                     ("12_persistencia.png", "<b>Se probó:</b> reiniciar la API y listar las reservas. <b>Resultado:</b> las filas y sus estados siguen guardados. <b>Demuestra:</b> que SQLite conserva los datos."))
        self.resumen_pruebas()
        self.evolucion()
        self.cierre()
        self.c.save()


if __name__ == "__main__":
    p = Presentacion()
    p.construir()
    print(f"PDF generado: {SALIDA} ({p.numero} páginas)")
    if p.pendientes:
        print(f"Capturas pendientes ({len(p.pendientes)}):", ", ".join(sorted(set(p.pendientes))))
    else:
        print("Todas las capturas fueron incorporadas.")
