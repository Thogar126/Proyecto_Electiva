# Evidencias

Guarda aquí las capturas de pantalla con **exactamente estos nombres** (formato `.png`). La presentación en PDF las incorpora automáticamente cuando ejecutas `python docs/generar_presentacion.py`.

Reglas: capturas legibles, datos ficticios y **sin la API key a la vista**.

| Archivo | Qué debe verse |
|---|---|
| `01_servicios_chat.png` | Gradio respondiendo «¿Qué servicios tienen?» con la lista y los precios |
| `02_multiples_turnos.png` | Una solicitud completada en dos mensajes (el bot pide la fecha y la hora que faltan) |
| `03_confirmacion_y_codigo.png` | El resumen con los botones y, tras confirmar, la reserva creada con su código |
| `04_fila_sqlite.png` | La consulta `SELECT` mostrando la fila de esa reserva en `reservas.db` |
| `05_cruce_409.png` | El aviso de error 409 al pedir un `corte` a las 10:30 con un `corte_barba` a las 10:00 |
| `06_reserva_contigua.png` | La reserva de las 11:00 aceptada |
| `07_disponibilidad.png` | Las horas libres antes y después de reservar |
| `08_modificar.png` | Una modificación a hora libre y una rechazada por hora ocupada |
| `09_cancelar.png` | La reserva cancelada y el horario otra vez libre |
| `10_descartar.png` | Una solicitud descartada y la tabla sin fila nueva |
| `11_dos_sesiones.png` | Dos ventanas (una privada) con conversaciones distintas |
| `12_persistencia.png` | Las reservas antes y después de reiniciar la API |
| `13_pytest.png` | La terminal con `27 passed` |
| `14_api_docs.png` | La página `http://127.0.0.1:8011/docs` con los endpoints |

Cada evidencia debe tener su pie en la bitácora (sección 16): qué se probaba, qué ocurrió y qué demuestra.
