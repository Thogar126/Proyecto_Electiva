# BarberBot · chatbot de reservas para una barbería

Proyecto del segundo corte de **Creación de chatbots** (Electiva II · EAM-2026II).

BarberBot permite a una persona consultar servicios y horarios libres, y **crear, modificar y cancelar reservas** conversando en español. Las reservas se guardan en una base de datos y **nunca se pueden cruzar**.

**Integrantes**

- Juan Sebastián Rodríguez
- Juan José Anduquia
- David Hurtado
- Thomas García

## Documentación de la entrega

| Documento | Contenido |
|---|---|
| [Bitácora del segundo corte](docs/Bitacora_Segundo_Corte.md) | Documentación principal: arquitectura, decisiones, pruebas, limitaciones y comparación con Flowise |
| [Presentación en PDF](docs/Presentacion_Segundo_Corte.pdf) | Explicación del proyecto para alguien que no asistió al curso |
| [Evidencias](docs/evidencias/) | Capturas de las pruebas (ver [LEEME](docs/evidencias/LEEME.md)) |
| [Bitácoras anteriores](docs/bitacoras_previas/) | Registros de las clases 3 y 4, como soporte |

## Cómo funciona (resumen)

```text
Persona → Gradio (7860) → chatbot_memoria.py → Groq (interpreta el mensaje)
              │
              └─ HTTP → FastAPI (8011) → almacen_sqlite.py → reservas.db (SQLite)
```

- **Gradio** muestra el chat y los botones (Enviar, Confirmar operación, Descartar solicitud, Reiniciar conversación).
- **Groq** convierte el mensaje en un plan en JSON (acción, cliente, servicio, fecha, hora, código). No decide si una hora está libre.
- **FastAPI** ejecuta las operaciones del negocio y devuelve los errores 404, 409 y 422.
- **SQLite** guarda las reservas; la comprobación del cruce y el guardado ocurren en una misma transacción.

## 1. Requisitos

- **Python 3.10 o superior** (se probó con 3.12). Para revisarlo: `python --version`.
- Una **API key de Groq** y el ID de un modelo de texto habilitado en tu cuenta (<https://console.groq.com>).
- Git. Docker es opcional.

## 2. Instalación desde una copia nueva

```powershell
git clone <URL_DEL_REPOSITORIO>
cd <carpeta_del_repositorio>        # la carpeta que contiene main.py
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Todos los comandos siguientes se ejecutan desde esa carpeta. En Linux o macOS usa `.venv/bin/python` en lugar de `.\.venv\Scripts\python.exe`.

## 3. Configuración

| Variable | Para qué sirve | Valor por defecto |
|---|---|---|
| `GROQ_API_KEY` | Clave de Groq (**nunca** se escribe en un archivo) | — |
| `GROQ_MODEL` | ID del modelo de Groq | — |
| `CHATBOT_API_URL` | Dirección de FastAPI | `http://127.0.0.1:8011` |
| `RESERVAS_DB` | Ruta del archivo SQLite | `reservas.db` junto a `main.py` |
| `GRADIO_SERVER_NAME` / `GRADIO_SERVER_PORT` | Dirección y puerto de Gradio | `127.0.0.1` / `7860` |

Para ver los modelos habilitados para tu clave, define `GROQ_API_KEY` y ejecuta `.\.venv\Scripts\python.exe listar_modelos_groq.py`.

> **Al pegar la clave en PowerShell** usa clic derecho. `Ctrl + V` dentro de `Read-Host -AsSecureString` no pega y deja la variable con un carácter de control, lo que hace que Groq responda `HTTP 400`.

## 4. Datos y base de datos

`reservas.db` **se crea sola** (con su tabla y su índice) la primera vez que arranca la API. No se incluye en el repositorio. Para tener datos ficticios de prueba:

```powershell
# Reservas de ejemplo en los próximos días (Laura, Andrés, Camilo)
.\.venv\Scripts\python.exe datos_prueba.py

# Opcional: migrar las reservas históricas de reservas.json (demuestra la migración)
.\.venv\Scripts\python.exe almacen_sqlite.py --migrar reservas.json --negocio negocio.json --base reservas.db
```

Para ver las filas (Python 3.12 o superior):

```powershell
.\.venv\Scripts\python.exe -m sqlite3 reservas.db "SELECT codigo, cliente, servicio, fecha, hora, estado FROM reservas;"
```

## 5. Ejecución (dos terminales)

**Terminal 1 · API**

```powershell
.\.venv\Scripts\python.exe -m uvicorn main:app --port 8011
```

Documentación interactiva: <http://127.0.0.1:8011/docs>

**Terminal 2 · Gradio**

```powershell
$env:CHATBOT_API_URL = "http://127.0.0.1:8011"
$env:GROQ_MODEL = "ID_DEL_MODELO"
$env:GROQ_API_KEY = Read-Host "API key de Groq"     # pega con clic derecho
.\.venv\Scripts\python.exe app_gradio.py
```

Abre <http://127.0.0.1:7860>. Para detener cualquiera de los dos procesos: `Ctrl + C`.

## 6. Comprobación inicial

1. Abre <http://127.0.0.1:8011/health>. **Resultado esperado:** `{"estado":"ok"}`.
2. Abre <http://127.0.0.1:8011/api/servicios>. **Resultado esperado:** los servicios `corte`, `barba`, `corte_barba` y `tinte` con precio y duración.
3. En Gradio escribe `¿Qué servicios tienen?`. **Resultado esperado:** la lista de servicios con precios.
4. Escribe `Quiero un corte, me llamo Laura`. **Resultado esperado:** el bot pide la fecha y la hora.
5. Escribe `Para el AAAA-MM-DD a las 10:00` (una fecha futura que no sea domingo). **Resultado esperado:** un resumen con el botón **Confirmar operación**.
6. Pulsa **Confirmar operación**. **Resultado esperado:** la reserva queda creada con un código, y aparece en «Reservas guardadas» y en la base de datos.

**Errores frecuentes**

| Síntoma | Causa probable |
|---|---|
| «Configura GROQ_API_KEY y GROQ_MODEL» | Variables no definidas en esa terminal; vuelve a definirlas y reinicia Gradio |
| «No pude conectar con Groq o FastAPI» | La API está apagada o `CHATBOT_API_URL` es incorrecta |
| `Error HTTP 400` de Groq | Clave mal pegada o modelo no habilitado |
| `Error HTTP 409` | El intervalo se cruza con otra reserva activa: elige otra hora |
| `Error HTTP 422` | Fecha o hora inválida, domingo, fuera de horario o fecha pasada |

## 7. Ejecución con Docker (opcional)

```powershell
Copy-Item .env.example .env      # completa GROQ_API_KEY y GROQ_MODEL en .env
docker compose up --build
```

Gradio queda en <http://127.0.0.1:7860> y la API en <http://127.0.0.1:8011/docs>. La base se guarda en `./data/reservas.db` y sobrevive a los reinicios. Para detener: `Ctrl + C` y luego `docker compose down`. El archivo `.env` está en `.gitignore`: **no lo subas**.

## 8. Pruebas automáticas

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q
```

Son 27 pruebas que no necesitan red ni clave (el modelo se simula). Cubren los cruces de intervalos, la reserva contigua, modificar y cancelar, las fechas inválidas, la concurrencia (8 hilos sobre el mismo intervalo), la persistencia, la migración y el flujo del chatbot en varios turnos.

### Regenerar la presentación en PDF

Guarda las capturas en `docs/evidencias/` con los nombres de [su LEEME](docs/evidencias/LEEME.md) y ejecuta (requiere `requirements-dev.txt`):

```powershell
.\.venv\Scripts\python.exe docs/generar_presentacion.py
```

El script incorpora cada captura en su página y avisa cuáles faltan. El enlace del repositorio se cambia en la constante `REPO` del script.

## 9. Endpoints de la API

| Método | Ruta | Acción | Errores |
|---|---|---|---|
| GET | `/health` | Estado del servicio | |
| GET | `/api/servicios` | Catálogo | |
| GET | `/api/disponibilidad?fecha=&servicio=` | Horas libres | 422 |
| GET | `/api/reservas` | Listar | |
| GET | `/api/reservas/{codigo}` | Consultar | 404 |
| POST | `/api/reservas` | Crear (requiere `confirmada: true`) | 400, 409, 422 |
| PUT | `/api/reservas/{codigo}` | Modificar | 404, 409, 422 |
| DELETE | `/api/reservas/{codigo}` | Cancelar (estado `cancelada`) | 404, 409 |

## 10. Reglas del negocio

- Horario: lunes a sábado, de 09:00 a 18:00, con citas cada 30 minutos (`negocio.json`).
- Cada servicio tiene su duración: una reserva ocupa **todo su intervalo**.
- Dos intervalos se cruzan cuando `inicio_nuevo < fin_existente` y `fin_nuevo > inicio_existente`. Terminar justo cuando otra empieza **no** es cruce.
- Cancelar cambia el estado a `cancelada`, libera el intervalo y conserva el histórico.

## 11. Limitaciones conocidas

No hay autenticación (cualquiera con el código puede consultar, modificar o cancelar), existe una sola agenda (sin varios barberos), el historial del chat vive solo en la sesión y depende de Groq para interpretar los mensajes. La lista completa está en la [bitácora](docs/Bitacora_Segundo_Corte.md#12-limitaciones-y-mejoras-pendientes).

## 12. Estructura del repositorio

```text
├── README.md
├── requirements.txt · requirements-dev.txt
├── .gitignore · .dockerignore · .env.example
├── main.py                API FastAPI del negocio
├── app_gradio.py          Interfaz Gradio
├── consulta_llm.py        Peticiones HTTP a Groq y FastAPI
├── chatbot_memoria.py     Historial, plan y confirmación
├── almacen_sqlite.py      SQLite: tabla, transacciones, disponibilidad
├── negocio.json           Catálogo, precios, duraciones y horario
├── reservas.json          Reservas históricas ficticias para la migración
├── datos_prueba.py        Reservas ficticias de ejemplo
├── listar_modelos_groq.py Lista los modelos habilitados para la clave
├── Dockerfile · docker-compose.yml
├── tests/                 27 pruebas automáticas
└── docs/
    ├── Bitacora_Segundo_Corte.md
    ├── Presentacion_Segundo_Corte.pdf
    ├── generar_presentacion.py
    ├── bitacoras_previas/
    └── evidencias/
```
